import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./marketing/pages/Home";
import CaseStudies from "./marketing/pages/CaseStudies";

import Dashboard from "./appui/pages/Dashboard";
import Agents from "./appui/pages/Agents";
import Calls from "./appui/pages/Calls";
import Contacts from "./appui/pages/Contacts";
import Knowledge from "./appui/pages/Knowledge";
import PhoneNumbers from "./appui/pages/PhoneNumbers";
import Workflows from "./appui/pages/Workflows";
import Analytics from "./appui/pages/Analytics";
import SettingsPage from "./appui/pages/Settings";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/case-studies" element={<CaseStudies />} />

        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/agents" element={<Agents />} />
        <Route path="/calls" element={<Calls />} />
        <Route path="/contacts" element={<Contacts />} />
        <Route path="/knowledge" element={<Knowledge />} />
        <Route path="/phone-numbers" element={<PhoneNumbers />} />
        <Route path="/workflows" element={<Workflows />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Routes>
    </BrowserRouter>
  );
}
