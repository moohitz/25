// The signature visual of the homepage: two vertical timelines, side by
// side, telling the exact same booking's story with one difference - a
// phone call that happened on time.
import type { ReactNode } from "react";

interface Event {
  time: string;
  label: string;
  tone: "ink" | "flame" | "violet";
}

const WITHOUT: Event[] = [
  { time: "12:00 PM", label: "Table for 6, booked by phone", tone: "ink" },
  { time: "5:50 PM", label: "Guest goes quiet. No one calls to check.", tone: "flame" },
  { time: "10:00 PM", label: "Table sat empty the rest of service.", tone: "flame" },
];

const WITH: Event[] = [
  { time: "12:00 PM", label: "Table for 6, booked by phone", tone: "ink" },
  { time: "5:50 PM", label: "BeVox calls to reconfirm. No answer.", tone: "violet" },
  { time: "6:05 PM", label: "Released and rebooked from the waitlist.", tone: "violet" },
];

function dotClass(tone: Event["tone"]) {
  if (tone === "flame") return "bg-flame";
  if (tone === "violet") return "bg-violet";
  return "bg-ink";
}

function Timeline({ events }: { events: Event[] }) {
  return (
    <ol className="relative">
      {events.map((e, i) => (
        <li key={e.time} className="relative flex gap-4 pb-7 last:pb-0">
          {i < events.length - 1 && (
            <span className="absolute left-[5px] top-3 h-full w-px bg-line-deep" />
          )}
          <span
            className={`relative mt-1.5 h-[11px] w-[11px] shrink-0 rounded-full ring-4 ring-paper ${dotClass(
              e.tone,
            )}`}
          />
          <div>
            <p className="num text-sm font-semibold text-ink">{e.time}</p>
            <p className="mt-0.5 text-sm leading-snug text-muted">{e.label}</p>
          </div>
        </li>
      ))}
    </ol>
  );
}

function Outcome({ tone, children }: { tone: "flame" | "violet"; children: ReactNode }) {
  const styles =
    tone === "flame"
      ? "border-flame/25 bg-flame-soft text-flame-deep"
      : "border-violet/25 bg-violet-soft text-violet";
  return (
    <div className={`mt-2 rounded-lg border px-4 py-3 text-sm font-medium ${styles}`}>
      {children}
    </div>
  );
}

export function InvisibleLossMeter() {
  return (
    <div className="grid gap-10 rounded-2xl border border-line bg-paper p-6 sm:grid-cols-2 sm:gap-8 sm:p-8">
      <div>
        <p className="kicker mb-6">Without BeVox</p>
        <Timeline events={WITHOUT} />
        <Outcome tone="flame">₹0 recovered. One table, one evening, gone.</Outcome>
      </div>
      <div className="border-t border-line pt-8 sm:border-l sm:border-t-0 sm:pl-8 sm:pt-0">
        <p className="kicker mb-6">With BeVox</p>
        <Timeline events={WITH} />
        <Outcome tone="violet">Table turned twice. Same no-show, zero loss.</Outcome>
      </div>
    </div>
  );
}
