import type { ReactNode } from "react";
import { MarketingNav } from "./MarketingNav";
import { MarketingFooter } from "./MarketingFooter";

export function MarketingPage({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-paper">
      <MarketingNav />
      {children}
      <MarketingFooter />
    </div>
  );
}
