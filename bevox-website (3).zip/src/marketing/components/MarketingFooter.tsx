import { Link } from "react-router-dom";
import logoLockup from "../../assets/logo-lockup.png";

const PRODUCT_LINKS = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/agents", label: "Agents" },
  { href: "/calls", label: "Calls" },
  { href: "/contacts", label: "Contacts" },
  { href: "/knowledge", label: "Knowledge base" },
  { href: "/phone-numbers", label: "Phone numbers" },
  { href: "/workflows", label: "Workflows" },
  { href: "/analytics", label: "Analytics" },
  { href: "/settings", label: "Settings" },
];

const COMPANY_LINKS = [
  { href: "/", label: "Home" },
  { href: "/case-studies", label: "Case studies" },
  { href: "/dashboard", label: "Console login" },
];

export function MarketingFooter() {
  return (
    <footer className="border-t border-line bg-ink text-white/70">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
        <div className="grid gap-10 sm:grid-cols-2 md:grid-cols-4">
          <div className="sm:col-span-2 md:col-span-1">
            <img
              src={logoLockup}
              alt="BeViral Media"
              className="h-7 w-auto brightness-0 invert"
            />
            <p className="mt-4 max-w-xs text-sm leading-6 text-white/50">
              Not just viral. BeViral. We build BeVox — the AI voice agent
              that answers every call your business would otherwise lose.
            </p>
          </div>

          <div>
            <p className="kicker mb-4 text-white/40">BeVox console</p>
            <ul className="space-y-2.5 text-sm">
              {PRODUCT_LINKS.map((l) => (
                <li key={l.href}>
                  <Link to={l.href} className="hover:text-white">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="kicker mb-4 text-white/40">Company</p>
            <ul className="space-y-2.5 text-sm">
              {COMPANY_LINKS.map((l) => (
                <li key={l.href}>
                  <Link to={l.href} className="hover:text-white">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="kicker mb-4 text-white/40">Based in</p>
            <p className="text-sm leading-6 text-white/60">
              Bengaluru, India
              <br />
              Built for hotels, clinics, salons,
              <br />
              and every business that runs on calls.
            </p>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-white/10 pt-6 text-xs text-white/40 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} BeViral Media. All rights reserved.</p>
          <p>BeVox — not just viral, BeViral.</p>
        </div>
      </div>
    </footer>
  );
}
