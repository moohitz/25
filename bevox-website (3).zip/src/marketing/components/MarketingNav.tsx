import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import logoLockup from "../../assets/logo-lockup.png";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/case-studies", label: "Case studies" },
];

export function MarketingNav() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 md:px-8">
        <Link to="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <img src={logoLockup} alt="BeViral Media" className="h-7 w-auto sm:h-8" />
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              to={l.href}
              className={`text-sm font-medium transition-colors ${
                location.pathname === l.href
                  ? "text-violet"
                  : "text-ink-soft hover:text-violet"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Link
            to="/dashboard"
            className="text-sm font-medium text-ink-soft hover:text-violet"
          >
            Console login
          </Link>
          <Link
            to="/case-studies"
            className="rounded-lg bg-ink px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-violet"
          >
            Talk to BeVox
          </Link>
        </div>

        <button
          className="p-1 text-ink md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-line px-5 pb-5 pt-2 md:hidden">
          <nav className="flex flex-col gap-1">
            {LINKS.map((l) => (
              <Link
                key={l.href}
                to={l.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-soft hover:bg-mist"
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/dashboard"
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-soft hover:bg-mist"
            >
              Console login
            </Link>
            <Link
              to="/case-studies"
              onClick={() => setOpen(false)}
              className="mt-2 rounded-lg bg-ink px-3 py-2.5 text-center text-sm font-medium text-white"
            >
              Talk to BeVox
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
