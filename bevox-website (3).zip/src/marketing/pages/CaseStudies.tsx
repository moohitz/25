import { useState } from "react";
import { Link } from "react-router-dom";
import {
  Building2,
  Stethoscope,
  Scissors,
  KeyRound,
  ArrowUpRight,
  CircleCheck,
} from "lucide-react";
import { MarketingPage } from "../components/MarketingPage";

interface Vertical {
  id: string;
  label: string;
  short: string;
  icon: typeof Building2;
  hero: string;
  useCase: string;
  lossTitle: string;
  lossBody: string;
  lossStat: string;
  whyOnly: string[];
}

const VERTICALS: Vertical[] = [
  {
    id: "hotels",
    label: "Hotels & Restaurants",
    short: "Hotels",
    icon: Building2,
    hero:
      "Every table and every room is inventory with an expiry time. BeVox makes sure none of it expires unsold.",
    useCase:
      "BeVox answers reservation and walk-in calls, confirms party size and time back to the guest, and calls to reconfirm 30 minutes before arrival. If a guest doesn't pick up or backs out, the table goes straight back to the host stand and the waitlist — not into a diary nobody's watching.",
    lossTitle: "The invisible loss in a restaurant",
    lossBody:
      "A table for six is booked at noon for that evening. The floor plan blocks it, the host turns away three other parties who ask for that slot. At 5:50 PM, the guest goes quiet. Nobody calls to check. The table sits reserved, and empty, through the rest of service — a full turn gone, for a party that was never coming, and a loss that shows up nowhere on the P&L.",
    lossStat:
      "Illustrative example: a mid-size restaurant losing just two peak-hour tables a week to silent no-shows can be looking at ₹1.5–2.5 lakh a year in covers that were already staffed for and never billed.",
    whyOnly: [
      "Voice cloned to your own host or receptionist's tone — regulars hear a familiar voice, not a call centre.",
      "Fluent in Hindi, Kannada, Tamil, Telugu, Marathi, Bengali and English — switches mid-call if your guest does.",
      "Reconfirms every booking 30 minutes out and releases the table the second a guest goes quiet, not the next morning.",
      "Slower and calmer with an elderly caller, quick and to the point with someone in a rush — paced from tone, automatically.",
      "Syncs directly with your table management or PMS software, so the floor plan is always the real picture.",
    ],
  },
  {
    id: "clinics",
    label: "Clinics & Hospitals",
    short: "Clinics",
    icon: Stethoscope,
    hero:
      "A doctor's chair sitting empty for one slot is a cost that already happened. BeVox is built to stop paying it.",
    useCase:
      "BeVox books appointments, reschedules on request, gives pre-visit instructions like fasting before a blood test or documents to carry, and runs 24-hour and 2-hour reconfirmation calls — so a slot is never lost to a reminder that simply never went out.",
    lossTitle: "The invisible loss in a clinic",
    lossBody:
      "A patient books a 4:30 PM slot and never confirms. That hold blocks another patient who might genuinely have been seen. The room, the nurse's time, the doctor's hour — all already spent, with zero revenue against it. Multiply that by the slots a small clinic quietly loses every week, and it becomes one of the largest leaks in the practice, with no line item to point at.",
    lossStat:
      "Illustrative example: a single-doctor clinic losing two no-show slots a day, six days a week, can be sitting on ₹3–5 lakh a year in chair time that was staffed and never used.",
    whyOnly: [
      "Handles bookings and pre-visit information within your clinic's own escalation and privacy rules.",
      "Speaks the language the patient is most comfortable in — a real factor in whether instructions are actually followed.",
      "Voice-cloned to sound like your own front-desk coordinator, so patients hear the same familiar voice every time.",
      "Slows down automatically for an anxious or elderly caller, and hands off medical questions to your staff immediately.",
    ],
  },
  {
    id: "salons",
    label: "Salons & Spas",
    short: "Salons",
    icon: Scissors,
    hero:
      "Chair time you don't sell today doesn't roll over to tomorrow. BeVox keeps the chair booked, not just the calendar.",
    useCase:
      "BeVox books, reschedules, sends reminders, and calls the standby list the moment a cancellation opens a slot — so a stylist's chair is booked back-to-back instead of sitting idle between appointments.",
    lossTitle: "The invisible loss in a salon",
    lossBody:
      "A 6 PM slot that cancels at 5:55 with nobody rebooked into it is revenue that's already gone by closing time. One stylist who could have taken one more client a day sits idle instead — and nobody notices, because there's nothing on paper to notice. The chair just sat there.",
    lossStat:
      "Illustrative example: one chair losing just one booking a day to unfilled cancellations adds up to 300+ empty slots a year — each one a service that was never sold.",
    whyOnly: [
      "Matched to your brand's tone — playful and quick for a trendy salon, calm and unhurried for a spa.",
      "Suggests add-on services based on a guest's own service history, the way your best stylist already does.",
      "Calls the waitlist within seconds of a cancellation, instead of waiting for someone to spot the gap.",
      "Runs the consultation in the client's own language — which builds more trust than a script read out in English.",
    ],
  },
  {
    id: "realestate",
    label: "Real Estate",
    short: "Real Estate",
    icon: KeyRound,
    hero:
      "A property lead is a race against three other brokers. BeVox makes sure you're always the one who answers first.",
    useCase:
      "BeVox answers every inbound property enquiry within one ring — including the 9 PM ones — qualifies budget, location and timeline on the spot, and books the site visit before the lead has a chance to cool off or call someone else.",
    lossTitle: "The invisible loss in real estate",
    lossBody:
      "A property lead is time-sensitive: the same buyer often calls three or four brokers the same afternoon, and books a visit with whoever answers first and sounds most prepared — not whoever has the better listing. A missed call after 7 PM tonight is, very often, a booked site visit for a competitor tomorrow morning. The lead never calls back to tell you that's what happened.",
    lossStat:
      "Illustrative example: a brokerage missing just three after-hours enquiries a week, at even a modest close rate, can be watching several lakh in commission walk to a competitor every year — with no missed-call alert that ever explains why.",
    whyOnly: [
      "Voice-cloned to your top-performing agent, or to you — the voice that already converts, now answering every call.",
      "Never off the clock: qualifies and books site visits at 11 PM exactly the way it does at 11 AM.",
      "Fluent in Hindi, Marathi and regional languages — critical the moment your buyer isn't calling in English.",
      "Every qualified lead is scored and pushed straight into your CRM and workflow automations, ready the instant a human needs it.",
    ],
  },
];

export default function CaseStudies() {
  const [active, setActive] = useState(VERTICALS[0].id);
  const v = VERTICALS.find((x) => x.id === active)!;

  return (
    <MarketingPage>
      <section className="border-b border-line">
        <div className="mx-auto max-w-6xl px-5 pb-10 pt-16 md:px-8 md:pt-24">
          <p className="kicker mb-4">Case studies, by industry</p>
          <h1 className="max-w-2xl font-display text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
            The use case. The loss. Why it has to be BeVox.
          </h1>
          <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-muted">
            Every business loses a little revenue it never sees. Here's
            exactly what that looks like in four kinds of business we work
            with most, and why a generic voice bot doesn't close it.
          </p>
        </div>
      </section>

      {/* Tabs */}
      <section className="sticky top-[65px] z-30 border-b border-line bg-paper/95 backdrop-blur">
        <div className="mx-auto max-w-6xl overflow-x-auto px-5 md:px-8">
          <div className="flex min-w-max gap-1 py-3">
            {VERTICALS.map((item) => {
              const isActive = item.id === active;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActive(item.id)}
                  className={`flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-ink text-white"
                      : "text-ink-soft hover:bg-mist"
                  }`}
                >
                  <Icon size={15} />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
        <p className="max-w-2xl font-display text-2xl font-medium leading-snug text-ink sm:text-3xl">
          {v.hero}
        </p>

        <div className="mt-14 grid gap-12 lg:grid-cols-3 lg:gap-10">
          {/* 1. Use case */}
          <div>
            <p className="kicker mb-3">01 · The use case</p>
            <p className="text-[15px] leading-relaxed text-ink-soft">
              {v.useCase}
            </p>
          </div>

          {/* 2. Why you need this */}
          <div>
            <p className="kicker mb-3">02 · Why you need this</p>
            <h3 className="text-base font-semibold text-ink">
              {v.lossTitle}
            </h3>
            <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">
              {v.lossBody}
            </p>
            <div className="mt-4 rounded-lg border border-flame/25 bg-flame-soft p-4">
              <p className="text-xs leading-relaxed text-flame-deep">
                {v.lossStat}
              </p>
            </div>
          </div>

          {/* 3. Why only BeVox */}
          <div>
            <p className="kicker mb-3">03 · Why only BeVox</p>
            <ul className="space-y-3">
              {v.whyOnly.map((point) => (
                <li key={point} className="flex gap-2.5 text-[15px] leading-relaxed text-ink-soft">
                  <CircleCheck size={16} className="mt-0.5 shrink-0 text-violet" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-16 flex flex-wrap items-center gap-4 border-t border-line pt-10">
          <Link
            to="/dashboard"
            className="inline-flex items-center gap-1.5 rounded-lg bg-ink px-5 py-3 text-sm font-medium text-white transition-colors hover:bg-violet"
          >
            Open the console <ArrowUpRight size={15} />
          </Link>
          <p className="text-sm text-muted">
            Or see how BeVox looks for {" "}
            <button
              onClick={() =>
                setActive(
                  VERTICALS[(VERTICALS.findIndex((x) => x.id === active) + 1) % VERTICALS.length].id,
                )
              }
              className="font-medium text-violet hover:text-violet-deep"
            >
              {VERTICALS[(VERTICALS.findIndex((x) => x.id === active) + 1) % VERTICALS.length].short}
            </button>
            .
          </p>
        </div>
      </section>
    </MarketingPage>
  );
}
