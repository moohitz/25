import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  Mic,
  Languages,
  Gauge,
  PhoneForwarded,
  Building2,
  Stethoscope,
  Scissors,
  KeyRound,
} from "lucide-react";
import { MarketingPage } from "../components/MarketingPage";
import { InvisibleLossMeter } from "../components/InvisibleLossMeter";

const CALL_SNIPPETS = [
  { lang: "English", quote: "Do you have a table for four around eight tonight?" },
  { lang: "Hindi", quote: "कल सुबह दस बजे अपॉइंटमेंट मिलेगी क्या?", note: "\u201cCan I get an appointment tomorrow at 10?\u201d" },
  { lang: "Kannada", quote: "ನಾಳೆ ಸಂಜೆ ಟೇಬಲ್ ಸಿಗುತ್ತದೆಯೇ?", note: "\u201cIs a table free tomorrow evening?\u201d" },
  { lang: "Marathi", quote: "उद्या दुपारची अपॉइंटमेंट मिळेल का?", note: "\u201cIs a slot free tomorrow afternoon?\u201d" },
];

const CAPABILITY_STATS = [
  { value: "24/7", label: "Answers every call, even after closing time" },
  { value: "<1s", label: "Time before the caller hears a voice" },
  { value: "12+", label: "Indian languages, switched mid-call" },
  { value: "100%", label: "Calls recorded, transcribed, and logged" },
];

const VERTICALS = [
  { icon: Building2, label: "Hotels & restaurants" },
  { icon: Stethoscope, label: "Clinics & hospitals" },
  { icon: Scissors, label: "Salons & spas" },
  { icon: KeyRound, label: "Real estate" },
];

export default function Home() {
  return (
    <MarketingPage>
      {/* ---------------- HERO ---------------- */}
      <section className="relative overflow-hidden border-b border-line">
        <div className="mx-auto max-w-6xl px-5 pb-16 pt-16 md:px-8 md:pb-24 md:pt-24">
          <p className="kicker mb-5">BeVox · by BeViral Media</p>
          <h1 className="max-w-3xl font-display text-5xl font-semibold leading-[1.05] tracking-tight text-ink sm:text-6xl md:text-7xl">
            Answer everything.
            <br />
            <span className="italic text-violet">Lose nothing.</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-soft">
            BeVox is the AI voice agent that picks up every call, books the
            table, fills the slot, and rings back before your customer
            tries someone else — in whichever language they called in.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link
              to="/case-studies"
              className="inline-flex items-center gap-1.5 rounded-lg bg-ink px-5 py-3 text-sm font-medium text-white transition-colors hover:bg-violet"
            >
              See how it pays for itself <ArrowUpRight size={15} />
            </Link>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-1.5 rounded-lg border border-line-deep px-5 py-3 text-sm font-medium text-ink transition-colors hover:border-violet hover:text-violet"
            >
              Open the console
            </Link>
          </div>

          {/* multilingual call strip */}
          <div className="mt-16 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {CALL_SNIPPETS.map((c) => (
              <div
                key={c.lang}
                className="min-w-0 rounded-xl border border-line bg-mist p-4"
              >
                <p className="kicker mb-2 !text-violet">{c.lang}</p>
                <p className="break-words text-sm font-medium text-ink">{c.quote}</p>
                {c.note && (
                  <p className="mt-1 break-words text-xs text-muted">{c.note}</p>
                )}
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs text-muted">
            Four callers, one agent. BeVox hears the language and answers
            in it — no menu, no transfer, no "please hold."
          </p>
        </div>
      </section>

      {/* ---------------- THE INVISIBLE LOSS ---------------- */}
      <section className="border-b border-line bg-mist">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <div className="mx-auto max-w-2xl text-center">
            <p className="kicker mb-4">The loss that never shows up on a report</p>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
              Not every loss is an expense. Most of them just look like
              nothing happened.
            </h2>
            <p className="mt-5 text-[15px] leading-relaxed text-muted">
              A table that sat empty isn't a line item anywhere. Nobody
              files a report for a slot that was never filled. It's the
              easiest kind of loss to run a business around — because you
              never actually see it happen.
            </p>
          </div>

          <div className="mx-auto mt-12 max-w-3xl">
            <InvisibleLossMeter />
          </div>

          <p className="mx-auto mt-8 max-w-2xl text-center text-sm text-muted">
            This is one table, one evening. Now multiply it by every
            no-show, every call that came in after closing, and every
            "we'll call you back" that quietly never happened.
          </p>
        </div>
      </section>

      {/* ---------------- CAPABILITY STATS ---------------- */}
      <section className="border-b border-line">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-20">
          <div className="grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-4">
            {CAPABILITY_STATS.map((s) => (
              <div key={s.label}>
                <div className="font-display text-4xl font-semibold text-violet sm:text-5xl">
                  {s.value}
                </div>
                <p className="mt-2 max-w-[16rem] text-sm text-muted">
                  {s.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- HOW IT WORKS ---------------- */}
      <section className="border-b border-line bg-mist">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <p className="kicker mb-4">How it works</p>
          <h2 className="max-w-lg font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
            Three steps. No call centre, no new hires.
          </h2>

          <div className="mt-12 grid gap-10 md:grid-cols-3">
            <Step
              n="01"
              icon={Mic}
              title="Clone the voice"
              body="Record a few minutes of your own receptionist, or your own voice. BeVox speaks in it — callers can't tell the difference."
            />
            <Step
              n="02"
              icon={Languages}
              title="Feed it what your staff already knows"
              body="Menus, tariffs, price lists, policies, appointment slots. The same knowledge your front desk uses — just always awake."
            />
            <Step
              n="03"
              icon={PhoneForwarded}
              title="Point your number at it"
              body="Inbound and outbound, 24/7. Every call recorded, transcribed, and pushed to your dashboard the moment it ends."
            />
          </div>
        </div>
      </section>

      {/* ---------------- WHY ONLY BEVOX ---------------- */}
      <section className="border-b border-line">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <div className="grid gap-12 md:grid-cols-2 md:gap-16">
            <div>
              <p className="kicker mb-4">Built for how India actually calls</p>
              <h2 className="font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
                A generic voice bot answers in English and hopes for the
                best. BeVox doesn't.
              </h2>
              <p className="mt-5 text-[15px] leading-relaxed text-muted">
                Most voice AI is built for a US call centre and localised
                as an afterthought. BeVox is built the other way round —
                for a front desk in Coorg, a clinic in Bengaluru, a broker
                in Pune.
              </p>
            </div>
            <div className="space-y-6">
              <Feature
                icon={Mic}
                title="Cloned to your voice, not a stock one"
                body="Your own receptionist's tone, or yours — recorded once, reused on every call."
              />
              <Feature
                icon={Languages}
                title="12+ Indian languages, mid-call"
                body="If a caller switches from English to Kannada halfway through, BeVox switches with them."
              />
              <Feature
                icon={Gauge}
                title="Adapts its pace to the caller"
                body="Slower and calmer for an anxious or elderly caller, quick and direct for someone in a hurry — set from tone, not a script."
              />
              <Feature
                icon={PhoneForwarded}
                title="Hands off to a human, instantly"
                body="The moment a call needs a person, BeVox transfers it and briefs your team — no cold handoffs."
              />
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- CASE STUDY TEASER ---------------- */}
      <section className="grain bg-violet">
        <div className="mx-auto max-w-6xl px-5 py-16 text-white md:px-8 md:py-24">
          <p className="kicker mb-4 !text-white/70">See it by industry</p>
          <h2 className="max-w-xl font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            The invisible loss looks different in a clinic than it does in
            a hotel. We wrote it down for both.
          </h2>
          <p className="mt-5 max-w-lg text-[15px] leading-relaxed text-white/75">
            Real use cases, the exact loss BeVox closes, and why voice
            cloning plus regional language actually matters for each one —
            for hotels, clinics, salons, and real estate.
          </p>

          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {VERTICALS.map((v) => (
              <div
                key={v.label}
                className="flex items-center gap-3 rounded-xl border border-white/15 bg-white/5 p-4"
              >
                <v.icon size={18} className="text-white/80" />
                <span className="text-sm font-medium">{v.label}</span>
              </div>
            ))}
          </div>

          <Link
            to="/case-studies"
            className="mt-10 inline-flex items-center gap-1.5 rounded-lg bg-white px-5 py-3 text-sm font-medium text-violet transition-colors hover:bg-white/90"
          >
            Read the case studies <ArrowUpRight size={15} />
          </Link>
        </div>
      </section>

      {/* ---------------- FINAL CTA ---------------- */}
      <section>
        <div className="mx-auto max-w-6xl px-5 py-16 text-center md:px-8 md:py-24">
          <h2 className="mx-auto max-w-2xl font-display text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
            Stop losing the calls you never hear about.
          </h2>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-1.5 rounded-lg bg-ink px-5 py-3 text-sm font-medium text-white transition-colors hover:bg-violet"
            >
              Open the console <ArrowUpRight size={15} />
            </Link>
            <Link
              to="/case-studies"
              className="inline-flex items-center gap-1.5 rounded-lg border border-line-deep px-5 py-3 text-sm font-medium text-ink transition-colors hover:border-violet hover:text-violet"
            >
              Explore case studies
            </Link>
          </div>
        </div>
      </section>
    </MarketingPage>
  );
}

function Step({
  n,
  icon: Icon,
  title,
  body,
}: {
  n: string;
  icon: typeof Mic;
  title: string;
  body: string;
}) {
  return (
    <div>
      <div className="flex items-center gap-3">
        <span className="num text-sm text-muted">{n}</span>
        <div className="grid h-9 w-9 place-items-center rounded-lg bg-violet-soft text-violet">
          <Icon size={16} />
        </div>
      </div>
      <h3 className="mt-4 text-base font-semibold text-ink">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
    </div>
  );
}

function Feature({
  icon: Icon,
  title,
  body,
}: {
  icon: typeof Mic;
  title: string;
  body: string;
}) {
  return (
    <div className="flex gap-4">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-mist text-violet">
        <Icon size={17} />
      </div>
      <div>
        <h3 className="text-sm font-semibold text-ink">{title}</h3>
        <p className="mt-1 text-sm leading-relaxed text-muted">{body}</p>
      </div>
    </div>
  );
}
