// Shared demo data for the BeVox console. Swap for live API data later —
// every page reads from here so the shape only needs to be defined once.

export type AgentUseCase =
  | "reservations"
  | "appointment_booking"
  | "lead_qualification";

export interface Agent {
  id: string;
  name: string;
  business: string;
  useCase: AgentUseCase;
  useCaseLabel: string;
  status: "ACTIVE" | "PAUSED";
  description: string;
  phone: string;
  voice: string;
  languages: string[];
  llm: string;
  totalCalls: number;
  lastActive: string;
  successRate: string;
}

export const agents: Agent[] = [
  {
    id: "agent-1",
    name: "Fern & Ivy Boutique Hotel — Reservations",
    business: "Fern & Ivy Boutique Hotel, Coorg",
    useCase: "reservations",
    useCaseLabel: "reservations desk",
    status: "ACTIVE",
    description:
      "Books tables and rooms, reconfirms 30 minutes before arrival, and re-releases the slot the moment a guest goes quiet.",
    phone: "+91 98450 12281",
    voice: "Ananya — cloned front-desk voice",
    languages: ["Hindi", "Kannada", "English"],
    llm: "gpt-4o-mini",
    totalCalls: 421,
    lastActive: "6 minutes ago",
    successRate: "95.1%",
  },
  {
    id: "agent-2",
    name: "Dr. Iyer Dental & Wellness Clinic — Scheduler",
    business: "Dr. Iyer Dental & Wellness Clinic, Bengaluru",
    useCase: "appointment_booking",
    useCaseLabel: "appointment booking",
    status: "ACTIVE",
    description:
      "Handles bookings, reschedules, pre-visit instructions, and the 24-hour and 2-hour reconfirmation calls that keep chair time full.",
    phone: "+91 80471 20933",
    voice: "Rohan — cloned coordinator voice",
    languages: ["Kannada", "Tamil", "English"],
    llm: "gpt-4o-mini",
    totalCalls: 356,
    lastActive: "22 minutes ago",
    successRate: "93.8%",
  },
  {
    id: "agent-3",
    name: "Skyline Realty — Site Visit Qualifier",
    business: "Skyline Realty, Pune",
    useCase: "lead_qualification",
    useCaseLabel: "lead qualification",
    status: "ACTIVE",
    description:
      "Answers every inbound property enquiry within one ring, qualifies budget and timeline, and books the site visit before the lead calls a competitor.",
    phone: "+91 96540 77102",
    voice: "Meera — cloned sales voice",
    languages: ["Hindi", "Marathi", "English"],
    llm: "claude-3-haiku",
    totalCalls: 512,
    lastActive: "2 minutes ago",
    successRate: "91.4%",
  },
];

export interface CallLog {
  id: string;
  caller: string;
  phone: string;
  agentId: string;
  agent: string;
  direction: "inbound" | "outbound";
  duration: string;
  outcome: string;
  cost: string;
  date: string;
  time: string;
}

export const callLogs: CallLog[] = [
  {
    id: "call-501",
    caller: "Devika Rao",
    phone: "+91 90082 34410",
    agentId: "agent-1",
    agent: "Fern & Ivy Boutique Hotel — Reservations",
    direction: "inbound",
    duration: "2m 44s",
    outcome: "table reconfirmed",
    cost: "₹6.70",
    date: "9 Aug 2026",
    time: "7:40 PM",
  },
  {
    id: "call-502",
    caller: "Arjun Mehta",
    phone: "+91 88267 90015",
    agentId: "agent-2",
    agent: "Dr. Iyer Dental & Wellness Clinic — Scheduler",
    direction: "inbound",
    duration: "1m 52s",
    outcome: "appointment booked",
    cost: "₹4.40",
    date: "9 Aug 2026",
    time: "6:12 PM",
  },
  {
    id: "call-503",
    caller: "Sana Kapoor",
    phone: "+91 99001 44782",
    agentId: "agent-3",
    agent: "Skyline Realty — Site Visit Qualifier",
    direction: "outbound",
    duration: "3m 02s",
    outcome: "site visit booked",
    cost: "₹7.90",
    date: "9 Aug 2026",
    time: "4:56 PM",
  },
  {
    id: "call-504",
    caller: "Unknown caller",
    phone: "+91 97123 55810",
    agentId: "agent-1",
    agent: "Fern & Ivy Boutique Hotel — Reservations",
    direction: "inbound",
    duration: "0m 38s",
    outcome: "no-show — table released",
    cost: "₹1.60",
    date: "9 Aug 2026",
    time: "5:50 PM",
  },
];

export interface Contact {
  id: string;
  name: string;
  company: string;
  score: number;
  requirement: string;
  phone: string;
  email: string;
  budget: string;
  timeline: string;
}

export const contacts: Contact[] = [
  {
    id: "c-1",
    name: "Devika Rao",
    company: "Walk-in guest",
    score: 9,
    requirement: "Table for 6, anniversary dinner, window seating",
    phone: "+91 90082 34410",
    email: "devika.rao@gmail.com",
    budget: "₹4,500 avg check",
    timeline: "This Saturday",
  },
  {
    id: "c-2",
    name: "Arjun Mehta",
    company: "Self",
    score: 8,
    requirement: "Root canal consultation + insurance check",
    phone: "+91 88267 90015",
    email: "arjun.mehta@outlook.com",
    budget: "Insurance + out of pocket",
    timeline: "This week",
  },
  {
    id: "c-3",
    name: "Sana Kapoor",
    company: "Kapoor Family Office",
    score: 9,
    requirement: "3BHK, Baner or Hinjewadi, ready-to-move",
    phone: "+91 99001 44782",
    email: "sana.kapoor@proton.me",
    budget: "₹1.4–1.7 Cr",
    timeline: "Next 30 days",
  },
];

export interface KnowledgeDoc {
  id: string;
  name: string;
  assignedTo: string;
  chunks: number;
  size: string;
  status: "INDEXED" | "PROCESSING";
}

export const knowledgeDocs: KnowledgeDoc[] = [
  {
    id: "kb-1",
    name: "Fern & Ivy — Menu, Room Tariffs & Reservation Policy 2026.pdf",
    assignedTo: "Fern & Ivy Boutique Hotel — Reservations",
    chunks: 24,
    size: "1.4 MB",
    status: "INDEXED",
  },
  {
    id: "kb-2",
    name: "Dr. Iyer Clinic — Treatment Price List & Insurance Panel.docx",
    assignedTo: "Dr. Iyer Dental & Wellness Clinic — Scheduler",
    chunks: 16,
    size: "820 KB",
    status: "INDEXED",
  },
  {
    id: "kb-3",
    name: "Skyline Realty — Active Inventory, Baner & Hinjewadi.xlsx",
    assignedTo: "Skyline Realty — Site Visit Qualifier",
    chunks: 31,
    size: "2.1 MB",
    status: "INDEXED",
  },
];

export interface PhoneNumber {
  number: string;
  provider: "twilio" | "exotel";
  assignedAgent: string;
  region: string;
  status: "ACTIVE" | "UNASSIGNED";
}

export const phoneNumbers: PhoneNumber[] = [
  {
    number: "+91 98450 12281",
    provider: "exotel",
    assignedAgent: "Fern & Ivy Boutique Hotel — Reservations",
    region: "Karnataka",
    status: "ACTIVE",
  },
  {
    number: "+91 80471 20933",
    provider: "exotel",
    assignedAgent: "Dr. Iyer Dental & Wellness Clinic — Scheduler",
    region: "Karnataka",
    status: "ACTIVE",
  },
  {
    number: "+91 96540 77102",
    provider: "twilio",
    assignedAgent: "Skyline Realty — Site Visit Qualifier",
    region: "Maharashtra",
    status: "ACTIVE",
  },
  {
    number: "+91 91234 60077",
    provider: "twilio",
    assignedAgent: "Unassigned",
    region: "Maharashtra",
    status: "UNASSIGNED",
  },
];

export interface Workflow {
  id: string;
  name: string;
  trigger: string;
  runs: number;
}

export const workflows: Workflow[] = [
  { id: "wf-1", name: "N8N Lead Sync to CRM", trigger: "lead_captured", runs: 214 },
  { id: "wf-2", name: "Google Calendar Booking Sync", trigger: "appointment_booked", runs: 168 },
  { id: "wf-3", name: "No-Show Table Release Alert", trigger: "reservation_no_show", runs: 47 },
  { id: "wf-4", name: "Human Call Transfer SMS", trigger: "call_transferred", runs: 12 },
];

export const weeklyCallVolume = [
  { day: "Mon", calls: 148, appointments: 21 },
  { day: "Tue", calls: 162, appointments: 24 },
  { day: "Wed", calls: 175, appointments: 29 },
  { day: "Thu", calls: 189, appointments: 31 },
  { day: "Fri", calls: 194, appointments: 34 },
  { day: "Sat", calls: 142, appointments: 26 },
  { day: "Sun", calls: 96, appointments: 15 },
];
