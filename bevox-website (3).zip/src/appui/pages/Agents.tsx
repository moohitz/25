import { Plus, Phone, Languages, Cpu } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { Card, StatusPill, Btn } from "../components/ui";
import { agents } from "../data/mockData";

export default function Agents() {
  return (
    <AppShell
      title="AI Voice Agents"
      description="Each agent is a cloned voice, tuned to one business, one job, and the languages its callers actually speak."
      action={
        <Btn primary>
          <Plus size={15} /> Create agent
        </Btn>
      }
    >
      <div className="space-y-5">
        {agents.map((a) => (
          <Card key={a.id} className="p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="mb-1 flex items-center gap-2">
                  <StatusPill tone="neutral">{a.useCaseLabel}</StatusPill>
                  <StatusPill tone="active">{a.status}</StatusPill>
                </div>
                <h3 className="font-display text-xl font-semibold text-ink">
                  {a.name}
                </h3>
                <p className="mt-1 max-w-xl text-sm text-muted">
                  {a.description}
                </p>
              </div>
              <div className="flex gap-2">
                <Btn>Test agent</Btn>
                <Btn>Edit configuration</Btn>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-4 border-t border-line pt-5 sm:grid-cols-4">
              <Field icon={Phone} label="Phone number" value={a.phone} />
              <Field icon={Cpu} label="LLM model" value={a.llm} />
              <Field
                icon={Languages}
                label="Voice & languages"
                value={`${a.voice.split(" —")[0]} · ${a.languages.join(", ")}`}
              />
              <div>
                <p className="text-xs text-muted">Total calls</p>
                <p className="num mt-1 text-sm font-semibold text-ink">
                  {a.totalCalls}{" "}
                  <span className="font-normal text-muted">
                    · last active {a.lastActive}
                  </span>
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}

function Field({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Phone;
  label: string;
  value: string;
}) {
  return (
    <div>
      <p className="flex items-center gap-1.5 text-xs text-muted">
        <Icon size={12} /> {label}
      </p>
      <p className="mt-1 text-sm font-medium text-ink">{value}</p>
    </div>
  );
}
