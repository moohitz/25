import { Plus, FileText } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { Card, Metric, StatusPill, Btn, SectionHeader } from "../components/ui";
import { knowledgeDocs } from "../data/mockData";

const totalChunks = knowledgeDocs.reduce((s, d) => s + d.chunks, 0);

export default function Knowledge() {
  return (
    <AppShell
      title="Knowledge Base & RAG"
      description="Upload menus, price lists, and policies. Your agent quotes from them live, on the call, instead of guessing."
      action={
        <Btn primary>
          <Plus size={15} /> Index new document
        </Btn>
      }
    >
      <div className="grid grid-cols-3 gap-6 rounded-xl border border-line bg-paper p-6">
        <Metric value={String(knowledgeDocs.length)} label="Indexed sources" accent />
        <Metric value={String(totalChunks)} label="Total vector chunks" />
        <Metric value="pgvector" label="Retrieval engine" />
      </div>

      <div className="mt-6">
        <SectionHeader title="Active knowledge documents" />
        <Card>
          <div className="divide-y divide-line">
            {knowledgeDocs.map((d) => (
              <div key={d.id} className="flex items-center gap-4 p-4">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-mist text-muted">
                  <FileText size={18} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-ink">
                    {d.name}
                  </p>
                  <p className="mt-0.5 truncate text-xs text-muted">
                    Assigned to {d.assignedTo} · {d.chunks} chunks · {d.size}
                  </p>
                </div>
                <StatusPill tone="active">{d.status}</StatusPill>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
