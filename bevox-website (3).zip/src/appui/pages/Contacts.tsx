import { Phone, Mail, Wallet, CalendarClock } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { Card } from "../components/ui";
import { contacts } from "../data/mockData";

export default function Contacts() {
  return (
    <AppShell
      title="Captured Leads & Contacts"
      description="Every qualified caller, with the details your team needs to follow up — pulled straight out of the conversation."
    >
      <div className="grid gap-5 sm:grid-cols-2">
        {contacts.map((c) => (
          <Card key={c.id} className="p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-display text-lg font-semibold text-ink">
                  {c.name}
                </h3>
                <p className="text-xs text-muted">{c.company}</p>
              </div>
              <div className="rounded-full bg-violet-soft px-2.5 py-1 text-xs font-semibold text-violet">
                Lead score {c.score}/10
              </div>
            </div>
            <p className="mt-3 text-sm text-ink-soft">{c.requirement}</p>
            <div className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-4 text-xs">
              <Detail icon={Phone} label="Phone" value={c.phone} />
              <Detail icon={Mail} label="Email" value={c.email} />
              <Detail icon={Wallet} label="Budget" value={c.budget} />
              <Detail icon={CalendarClock} label="Timeline" value={c.timeline} />
            </div>
          </Card>
        ))}
      </div>
    </AppShell>
  );
}

function Detail({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Phone;
  label: string;
  value: string;
}) {
  return (
    <div>
      <p className="flex items-center gap-1.5 text-muted">
        <Icon size={12} /> {label}
      </p>
      <p className="mt-0.5 font-medium text-ink">{value}</p>
    </div>
  );
}
