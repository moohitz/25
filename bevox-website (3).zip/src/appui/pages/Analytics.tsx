import { AppShell } from "../components/AppShell";
import { Card, Metric, SectionHeader } from "../components/ui";
import { agents } from "../data/mockData";

const costLayers = [
  { label: "STT (Deepgram Nova-2)", rate: "₹0.36 / min", total: "₹3.80" },
  { label: "LLM tokens (OpenAI / Anthropic)", rate: "₹0.012 / 1k tokens", total: "₹0.25" },
  { label: "TTS synthesis (ElevenLabs)", rate: "₹1.25 / 1k chars", total: "₹1.75" },
  { label: "Telephony (Exotel / Twilio)", rate: "₹1.10 / min", total: "₹5.40" },
];

export default function Analytics() {
  return (
    <AppShell
      title="Call Analytics & Cost Tracking"
      description="A granular breakdown of what every call actually costs — and what every recovered booking is worth against it."
    >
      <div className="grid grid-cols-2 gap-6 rounded-xl border border-line bg-paper p-6 md:grid-cols-4">
        <Metric value="₹11.20" label="Total infra cost, this week" accent />
        <Metric value="₹5.61" label="Avg cost / call" />
        <Metric value="286" label="Spoken minutes, this week" />
        <Metric value="38.5%" label="Conversion rate" delta="+4.2%" />
      </div>

      <div className="mt-6">
        <SectionHeader title="Cost distribution by orchestration layer" />
        <Card className="divide-y divide-line">
          {costLayers.map((l) => (
            <div key={l.label} className="flex items-center justify-between gap-4 p-4 text-sm">
              <span className="text-ink-soft">{l.label}</span>
              <span className="num text-xs text-muted">{l.rate}</span>
              <span className="num font-medium text-ink">{l.total}</span>
            </div>
          ))}
        </Card>
      </div>

      <div className="mt-6">
        <SectionHeader title="Per-agent cost & performance" />
        <Card className="overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-mist text-xs text-muted">
                <th className="px-4 py-3 font-medium">Agent</th>
                <th className="hidden px-4 py-3 font-medium sm:table-cell">
                  Use case
                </th>
                <th className="px-4 py-3 font-medium">Calls</th>
                <th className="hidden px-4 py-3 font-medium md:table-cell">
                  Avg duration
                </th>
                <th className="px-4 py-3 font-medium">Success rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {agents.map((a) => (
                <tr key={a.id}>
                  <td className="px-4 py-3 font-medium text-ink">{a.name}</td>
                  <td className="hidden px-4 py-3 text-xs capitalize text-muted sm:table-cell">
                    {a.useCaseLabel}
                  </td>
                  <td className="num px-4 py-3 text-xs text-ink">
                    {a.totalCalls}
                  </td>
                  <td className="num hidden px-4 py-3 text-xs text-muted md:table-cell">
                    2m 08s
                  </td>
                  <td className="num px-4 py-3 text-xs font-medium text-violet">
                    {a.successRate}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </AppShell>
  );
}
