import { useState, type ReactNode } from "react";
import { PlayCircle } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { Card, StatusPill } from "../components/ui";
import { agents, callLogs } from "../data/mockData";

export default function Calls() {
  const [filter, setFilter] = useState<string>("all");
  const filtered =
    filter === "all" ? callLogs : callLogs.filter((c) => c.agentId === filter);

  return (
    <AppShell
      title="Call Logs & Transcripts"
      description="Every conversation, recorded, transcribed, and summarised — with the outcome that matters, front and centre."
    >
      <div className="mb-4 flex flex-wrap gap-2">
        <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
          All agents ({callLogs.length})
        </FilterChip>
        {agents.map((a) => (
          <FilterChip
            key={a.id}
            active={filter === a.id}
            onClick={() => setFilter(a.id)}
          >
            {a.name.split(" — ")[0]}
          </FilterChip>
        ))}
      </div>

      <Card className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-mist text-xs text-muted">
              <th className="px-4 py-3 font-medium">Caller</th>
              <th className="hidden px-4 py-3 font-medium sm:table-cell">
                Agent
              </th>
              <th className="hidden px-4 py-3 font-medium md:table-cell">
                Direction
              </th>
              <th className="px-4 py-3 font-medium">Duration</th>
              <th className="px-4 py-3 font-medium">Outcome</th>
              <th className="hidden px-4 py-3 font-medium sm:table-cell">
                Cost
              </th>
              <th className="px-4 py-3 font-medium">Time</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {filtered.map((c) => (
              <tr key={c.id}>
                <td className="px-4 py-3">
                  <div className="font-medium text-ink">{c.caller}</div>
                  <div className="text-xs text-muted">{c.phone}</div>
                </td>
                <td className="hidden px-4 py-3 text-xs text-muted sm:table-cell">
                  {c.agent}
                </td>
                <td className="hidden px-4 py-3 text-xs capitalize text-muted md:table-cell">
                  {c.direction}
                </td>
                <td className="num px-4 py-3 text-xs text-ink">
                  {c.duration}
                </td>
                <td className="px-4 py-3">
                  <StatusPill tone={c.outcome.includes("no-show") ? "warn" : "active"}>
                    {c.outcome}
                  </StatusPill>
                </td>
                <td className="num hidden px-4 py-3 text-xs text-muted sm:table-cell">
                  {c.cost}
                </td>
                <td className="px-4 py-3 text-xs text-muted">{c.time}</td>
                <td className="px-4 py-3">
                  <button className="flex items-center gap-1 text-xs font-medium text-violet hover:text-violet-deep">
                    <PlayCircle size={14} /> Play
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </AppShell>
  );
}

function FilterChip({
  children,
  active,
  onClick,
}: {
  children: ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
        active
          ? "border-violet bg-violet-soft text-violet"
          : "border-line-deep text-muted hover:border-violet hover:text-violet"
      }`}
    >
      {children}
    </button>
  );
}
