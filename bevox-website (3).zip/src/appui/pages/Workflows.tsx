import { AppShell } from "../components/AppShell";
import { Card, Btn, SectionHeader } from "../components/ui";
import { workflows } from "../data/mockData";

const SAMPLE_PAYLOAD = `{
  "event": "reservation_no_show",
  "timestamp": "2026-08-09T17:50:00.000Z",
  "data": {
    "call_id": "call-504",
    "agent_id": "agent-1",
    "customer": {
      "name": "Unknown caller",
      "phone": "+91 97123 55810"
    },
    "table_size": 6,
    "held_since": "2026-08-09T12:00:00.000Z",
    "released_to_waitlist": true
  }
}`;

export default function Workflows() {
  return (
    <AppShell
      title="Workflow Automation"
      description="Fire a webhook the instant a call ends, a lead is captured, or a table gets released — n8n picks it up from there."
    >
      <div className="space-y-4">
        {workflows.map((w) => (
          <Card key={w.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
            <div>
              <h3 className="font-medium text-ink">{w.name}</h3>
              <p className="mt-1 text-xs text-muted">
                Trigger: <span className="num">{w.trigger}</span> · Runs
                executed: <span className="num">{w.runs}</span>
              </p>
            </div>
            <Btn>Test webhook</Btn>
          </Card>
        ))}
      </div>

      <div className="mt-6">
        <SectionHeader title="Standard webhook payload" />
        <div className="overflow-x-auto rounded-xl border border-line bg-ink p-5">
          <pre className="font-mono text-xs leading-6 text-white/85">
            {SAMPLE_PAYLOAD}
          </pre>
        </div>
      </div>
    </AppShell>
  );
}
