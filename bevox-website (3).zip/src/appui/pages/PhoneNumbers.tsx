import { Plus } from "lucide-react";
import { AppShell } from "../components/AppShell";
import { Card, StatusPill, Btn } from "../components/ui";
import { phoneNumbers } from "../data/mockData";

export default function PhoneNumbers() {
  return (
    <AppShell
      title="Telephony Phone Numbers"
      description="Inbound and outbound numbers, wired through Exotel and Twilio, each pointed at one agent."
      action={
        <Btn primary>
          <Plus size={15} /> Add number
        </Btn>
      }
    >
      <Card className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-mist text-xs text-muted">
              <th className="px-4 py-3 font-medium">Phone number</th>
              <th className="px-4 py-3 font-medium">Provider</th>
              <th className="hidden px-4 py-3 font-medium sm:table-cell">
                Assigned agent
              </th>
              <th className="hidden px-4 py-3 font-medium md:table-cell">
                Region
              </th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {phoneNumbers.map((n) => (
              <tr key={n.number}>
                <td className="num px-4 py-3 font-medium text-ink">
                  {n.number}
                </td>
                <td className="px-4 py-3 text-xs capitalize text-muted">
                  {n.provider}
                </td>
                <td className="hidden px-4 py-3 text-xs text-muted sm:table-cell">
                  {n.assignedAgent}
                </td>
                <td className="hidden px-4 py-3 text-xs text-muted md:table-cell">
                  {n.region}
                </td>
                <td className="px-4 py-3">
                  <StatusPill tone={n.status === "ACTIVE" ? "active" : "neutral"}>
                    {n.status}
                  </StatusPill>
                </td>
                <td className="px-4 py-3">
                  <button className="text-xs font-medium text-violet hover:text-violet-deep">
                    Assign agent
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </AppShell>
  );
}
