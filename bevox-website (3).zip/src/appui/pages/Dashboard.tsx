import { Plus, CircleAlert } from "lucide-react";
import { AppShell } from "../components/AppShell";
import {
  Card,
  SectionHeader,
  Metric,
  StatusPill,
  Btn,
  LinkArrow,
} from "../components/ui";
import { agents, callLogs, weeklyCallVolume } from "../data/mockData";

export default function Dashboard() {
  const maxCalls = Math.max(...weeklyCallVolume.map((d) => d.calls));

  return (
    <AppShell
      title="Good morning."
      description={
        <>
          Your agents handled <b className="text-ink">446 calls</b> this
          week, and released <b className="text-ink">12 no-show slots</b>{" "}
          back into inventory before they went to waste.
        </>
      }
      action={
        <Btn primary href="/agents">
          <Plus size={15} /> Create an agent
        </Btn>
      }
    >
      {/* Primary metrics */}
      <div className="grid grid-cols-2 gap-x-6 gap-y-6 rounded-xl border border-line bg-paper p-6 md:grid-cols-4">
        <Metric value="446" label="Calls handled" delta="+14%" accent />
        <Metric value="76" label="Leads captured" delta="+18%" />
        <Metric value="38" label="Appointments booked" delta="+22%" />
        <Metric value="12" label="No-show slots recovered" delta="+3" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        {/* Chart */}
        <Card className="p-6">
          <SectionHeader
            title="Calls and appointments"
            description="Inbound volume vs. outcomes, last 7 days"
          />
          <div className="mb-4 flex items-center gap-5 text-xs text-muted">
            <span className="flex items-center gap-1.5">
              <i className="inline-block h-2 w-2 rounded-full bg-violet" />
              Calls
            </span>
            <span className="flex items-center gap-1.5">
              <i className="inline-block h-2 w-2 rounded-full bg-flame" />
              Appointments booked
            </span>
          </div>
          <div className="flex h-48 items-end gap-3 sm:gap-5">
            {weeklyCallVolume.map((d) => (
              <div key={d.day} className="flex flex-1 flex-col items-center gap-2">
                <div className="flex h-40 w-full items-end justify-center gap-1">
                  <div
                    className="w-2.5 rounded-t bg-violet/85 sm:w-3.5"
                    style={{ height: `${(d.calls / maxCalls) * 100}%` }}
                    title={`${d.calls} calls`}
                  />
                  <div
                    className="w-2.5 rounded-t bg-flame/80 sm:w-3.5"
                    style={{ height: `${(d.appointments / maxCalls) * 100}%` }}
                    title={`${d.appointments} appointments`}
                  />
                </div>
                <span className="text-[11px] text-muted">{d.day}</span>
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-6">
          <Card className="p-5">
            <div className="flex items-center gap-2 text-flame-deep">
              <CircleAlert size={17} />
              <b className="text-sm text-ink">3 calls need a look</b>
            </div>
            <p className="mt-2 text-xs leading-5 text-muted">
              Fern &amp; Ivy's reservation line couldn't reach a guest before
              their hold expired. Review before tonight's service.
            </p>
            <div className="mt-3">
              <LinkArrow href="/calls" label="Review calls" />
            </div>
          </Card>

          <Card className="p-5">
            <p className="kicker mb-2">This week, made visible</p>
            <p className="text-sm leading-6 text-ink-soft">
              12 tables and appointment slots would have sat empty waiting
              on a no-show. BeVox reconfirmed each one on time and refilled
              them from the waitlist instead.
            </p>
          </Card>
        </div>
      </div>

      {/* Agents */}
      <div className="mt-6">
        <SectionHeader
          title="Your agents"
          action={
            <LinkArrow href="/agents" label={`See all agents (${agents.length})`} />
          }
        />
        <Card>
          <div className="divide-y divide-line">
            {agents.map((a) => (
              <div key={a.id} className="flex items-center gap-4 p-4">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-violet-soft font-display font-semibold text-violet">
                  {a.name[0]}
                </div>
                <div className="min-w-0 flex-1">
                  <b className="block truncate text-sm text-ink">{a.name}</b>
                  <p className="truncate text-xs text-muted">
                    {a.voice.split(" —")[0]} · {a.totalCalls} calls this
                    month
                  </p>
                </div>
                <StatusPill tone="active">Active</StatusPill>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent calls */}
      <div className="mt-6">
        <SectionHeader
          title="Recent calls"
          action={<LinkArrow href="/calls" label="See all calls" />}
        />
        <Card>
          <div className="divide-y divide-line">
            {callLogs.slice(0, 4).map((c) => (
              <div
                key={c.id}
                className="flex flex-wrap items-center gap-3 p-4 text-sm"
              >
                <span className="min-w-[150px] flex-1 font-medium text-ink">
                  {c.caller}
                  <small className="ml-3 font-normal text-muted">
                    {c.time}
                  </small>
                </span>
                <span className="text-xs text-muted">{c.agent}</span>
                <StatusPill
                  tone={c.outcome.includes("no-show") ? "warn" : "active"}
                >
                  {c.outcome}
                </StatusPill>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
