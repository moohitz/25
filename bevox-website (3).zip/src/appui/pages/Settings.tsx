import { AppShell } from "../components/AppShell";
import { Card, StatusPill, Btn, SectionHeader } from "../components/ui";

const providers = [
  "OpenAI LLM",
  "Anthropic LLM",
  "Google Gemini",
  "Deepgram STT",
  "ElevenLabs TTS",
  "Exotel / Twilio Telephony",
];

const keys = [
  { label: "OpenAI API key", env: "OPENAI_API_KEY" },
  { label: "Anthropic API key", env: "ANTHROPIC_API_KEY" },
  { label: "Google Gemini API key", env: "GOOGLE_API_KEY" },
  { label: "Deepgram STT key", env: "DEEPGRAM_API_KEY" },
  { label: "ElevenLabs TTS key", env: "ELEVENLABS_API_KEY" },
  { label: "Exotel API key", env: "EXOTEL_API_KEY" },
  { label: "Twilio account SID", env: "TWILIO_ACCOUNT_SID" },
  { label: "Twilio auth token", env: "TWILIO_AUTH_TOKEN" },
];

export default function SettingsPage() {
  return (
    <AppShell
      title="Platform Settings"
      description="Provider connections, API credentials, and the database extensions BeVox runs on."
      action={<Btn primary>Save settings</Btn>}
    >
      <SectionHeader title="Provider status" />
      <Card className="grid grid-cols-2 gap-4 p-5 sm:grid-cols-3">
        {providers.map((p) => (
          <div key={p} className="flex items-center justify-between gap-2">
            <span className="text-sm text-ink-soft">{p}</span>
            <StatusPill tone="simulated">simulated</StatusPill>
          </div>
        ))}
      </Card>

      <div className="mt-6">
        <SectionHeader title="AI & infrastructure API keys" />
        <Card className="divide-y divide-line">
          {keys.map((k) => (
            <div key={k.env} className="flex items-center justify-between gap-4 p-4">
              <div>
                <p className="text-sm font-medium text-ink">{k.label}</p>
                <p className="num text-xs text-muted">{k.env}</p>
              </div>
              <input
                type="password"
                placeholder="••••••••••••••••"
                className="w-40 rounded-lg border border-line-deep bg-mist px-3 py-1.5 text-sm text-ink outline-none focus:border-violet sm:w-56"
              />
            </div>
          ))}
        </Card>
      </div>
    </AppShell>
  );
}
