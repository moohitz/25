import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";

export function Card({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-xl border border-line bg-paper ${className}`}
    >
      {children}
    </div>
  );
}

export function SectionHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        <h2 className="text-lg font-semibold tracking-tight text-ink">
          {title}
        </h2>
        {description && (
          <p className="mt-1 text-sm text-muted">{description}</p>
        )}
      </div>
      {action}
    </div>
  );
}

export function Metric({
  value,
  label,
  delta,
  accent = false,
}: {
  value: string;
  label: string;
  delta?: string;
  accent?: boolean;
}) {
  return (
    <div className="py-1">
      <div
        className={`num text-3xl font-semibold tracking-tight ${
          accent ? "text-violet" : "text-ink"
        }`}
      >
        {value}
      </div>
      <div className="mt-1.5 flex items-center gap-2">
        <span className="text-xs text-muted">{label}</span>
        {delta && (
          <span className="num text-xs font-medium text-violet">
            {delta}
          </span>
        )}
      </div>
    </div>
  );
}

export function StatusPill({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "active" | "neutral" | "warn" | "simulated";
}) {
  const tones: Record<string, string> = {
    active: "bg-violet-soft text-violet",
    neutral: "bg-mist text-ink-soft",
    warn: "bg-flame-soft text-flame-deep",
    simulated: "border border-line-deep text-muted",
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function Btn({
  children,
  primary = false,
  href,
  onClick,
  className = "",
  type = "button",
}: {
  children: ReactNode;
  primary?: boolean;
  href?: string;
  onClick?: () => void;
  className?: string;
  type?: "button" | "submit";
}) {
  const base =
    "inline-flex items-center justify-center gap-1.5 rounded-lg px-3.5 py-2 text-sm font-medium transition-colors";
  const styles = primary
    ? "bg-ink text-white hover:bg-violet"
    : "border border-line-deep text-ink hover:border-violet hover:text-violet bg-paper";
  if (href) {
    return (
      <Link to={href} className={`${base} ${styles} ${className}`}>
        {children}
      </Link>
    );
  }
  return (
    <button
      type={type}
      onClick={onClick}
      className={`${base} ${styles} ${className}`}
    >
      {children}
    </button>
  );
}

export function LinkArrow({ href, label }: { href: string; label: string }) {
  return (
    <Link
      to={href}
      className="inline-flex items-center gap-1 text-xs font-semibold text-violet hover:text-violet-deep"
    >
      {label} <ArrowUpRight size={13} />
    </Link>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return (
    <kbd className="rounded border border-line-deep bg-mist px-1.5 py-0.5 font-mono text-[11px] text-muted">
      {children}
    </kbd>
  );
}
