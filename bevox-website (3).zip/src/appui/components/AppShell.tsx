import type { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Bot,
  PhoneCall,
  Users,
  BookOpen,
  Hash,
  Workflow as WorkflowIcon,
  BarChart3,
  Settings as SettingsIcon,
  ArrowLeft,
} from "lucide-react";
import logoMark from "../../assets/logo-mark.png";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/agents", label: "Agents", icon: Bot },
  { href: "/calls", label: "Calls", icon: PhoneCall },
  { href: "/contacts", label: "Contacts", icon: Users },
  { href: "/knowledge", label: "Knowledge Base", icon: BookOpen },
  { href: "/phone-numbers", label: "Phone Numbers", icon: Hash },
  { href: "/workflows", label: "Workflows", icon: WorkflowIcon },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/settings", label: "Settings", icon: SettingsIcon },
];

export function AppShell({
  title,
  description,
  action,
  children,
}: {
  title: string;
  description?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
}) {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-mist md:flex">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 border-r border-line bg-paper md:flex md:flex-col">
        <div className="flex items-center gap-2 px-5 py-5">
          <img src={logoMark} alt="" className="h-7 w-auto" />
          <div className="leading-tight">
            <div className="font-display text-base font-semibold text-ink">
              BeVox
            </div>
            <div className="text-[11px] text-muted">by BeViral Media</div>
          </div>
        </div>

        <nav className="flex-1 space-y-0.5 px-3 py-2">
          {NAV.map((item) => {
            const active = location.pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                to={item.href}
                className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  active
                    ? "bg-violet-soft text-violet"
                    : "text-ink-soft hover:bg-mist"
                }`}
              >
                <Icon size={16} strokeWidth={2} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="space-y-3 border-t border-line px-4 py-4">
          <Link
            to="/"
            className="flex items-center gap-1.5 text-xs font-medium text-muted hover:text-violet"
          >
            <ArrowLeft size={13} /> Back to beviralmedia.com
          </Link>
          <div className="flex items-center gap-2 rounded-lg bg-mist px-3 py-2">
            <div className="grid h-7 w-7 place-items-center rounded-full bg-violet text-xs font-semibold text-white">
              ZK
            </div>
            <div className="leading-tight">
              <div className="text-xs font-semibold text-ink">Zack</div>
              <div className="text-[11px] text-muted">BeViral Media</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex-1">
        <header className="flex items-center justify-between gap-4 border-b border-line bg-paper px-5 py-4 md:px-8">
          <div className="flex items-center gap-2 md:hidden">
            <img src={logoMark} alt="" className="h-6 w-auto" />
            <span className="font-display font-semibold">BeVox</span>
          </div>
          <div className="hidden md:block">
            <p className="text-xs text-muted">production environment</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-1.5 rounded-full bg-violet-soft px-2.5 py-1 text-[11px] font-semibold text-violet sm:inline-flex">
              <span className="h-1.5 w-1.5 rounded-full bg-violet" />
              Providers active
            </span>
          </div>
        </header>

        <main className="px-5 py-8 md:px-8">
          <div className="mx-auto max-w-6xl">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div>
                <h1 className="font-display text-3xl font-semibold tracking-tight text-ink">
                  {title}
                </h1>
                {description && (
                  <p className="mt-2 max-w-xl text-[15px] text-muted">
                    {description}
                  </p>
                )}
              </div>
              {action}
            </div>
            {children}
          </div>
        </main>

        {/* mobile bottom nav */}
        <nav className="fixed inset-x-0 bottom-0 z-10 flex justify-between overflow-x-auto border-t border-line bg-paper px-2 py-1.5 md:hidden">
          {NAV.map((item) => {
            const active = location.pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                to={item.href}
                className={`flex flex-col items-center gap-0.5 rounded-lg px-2.5 py-1.5 text-[10px] font-medium ${
                  active ? "text-violet" : "text-muted"
                }`}
              >
                <Icon size={16} />
                {item.label.split(" ")[0]}
              </Link>
            );
          })}
        </nav>
        <div className="h-14 md:hidden" />
      </div>
    </div>
  );
}
