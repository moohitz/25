# BeVox by BeViral Media — website + console

This is your new site: the marketing site (Home, Case Studies) and the
BeVox product console (Dashboard, Agents, Calls, Contacts, Knowledge
Base, Phone Numbers, Workflows, Analytics, Settings) — all in one React
app, all your original 9 console pages kept at their original URLs.

## Deploy to Netlify (no account setup needed) — the fast way

1. In this folder, open **`dist/`** — that's the finished, built site.
2. Go to https://app.netlify.com/drop
3. Drag the whole **`dist`** folder onto that page.
4. Netlify gives you a live URL in about 10 seconds. Done.

You can rename the site (and add a custom domain) from the Netlify site
settings afterwards — "Site configuration" -> "Change site name", or
"Domain management" to point your own domain at it.

## Deploy via Git (if you want auto-deploys on every change)

1. Push this whole folder to a GitHub repo.
2. In Netlify: "Add new site" -> "Import an existing project" -> pick the repo.
3. Build command: `npm run build`
4. Publish directory: `dist`
   (both are already set in `netlify.toml`, so Netlify should pick them
   up automatically)
5. Deploy.

## Making changes later

This is a normal Vite + React + TypeScript + Tailwind project.

```
npm install       # first time only
npm run dev       # local dev server with hot reload
npm run build     # production build, outputs to dist/
```

Where things live:
- `src/marketing/pages/Home.tsx` - homepage copy and sections
- `src/marketing/pages/CaseStudies.tsx` - the 4 case-study tabs (all
  copy is in the `VERTICALS` array at the top of the file)
- `src/marketing/components/InvisibleLossMeter.tsx` - the before/after
  timeline diagram on the homepage
- `src/appui/pages/` - the 9 console pages
- `src/appui/data/mockData.ts` - all the demo data shown in the
  console (agents, calls, contacts, etc.) - swap this for real API
  calls whenever the backend is ready
- `src/index.css` - colors, fonts, and design tokens in one place
  (the `@theme` block near the top)

## A couple of things worth knowing

- The console pages currently show realistic demo data, not live data
  - the same as your current site. Settings shows all provider keys
  as "simulated," matching what you had before.
- Every one of your original console page URLs still works exactly as
  before: `/dashboard`, `/agents`, `/calls`, `/contacts`, `/knowledge`,
  `/phone-numbers`, `/workflows`, `/analytics`, `/settings`.
- The `_redirects` file in `public/` is required for the console page
  URLs to work once deployed (client-side routing) - don't delete it.
